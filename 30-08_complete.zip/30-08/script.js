/* function myFunction(){
    var x = document.createElement("TABLE");
    x.setAttribute("id", "myTable");
    document.body.appendChild(x);
  
    var y = document.createElement("TR");
    y.setAttribute("id", "myTr");
    document.getElementById("myTable").appendChild(y);

    var z = document.createElement("td");
    var a = document.createTextNode("");
     z.appendChild(a);
    document.getElementById("myTr").appendChild(z);
} */

function myFunction(){
    var table = document.getElementById("tbl1");
    var row = table.insertRow(0);
    var cell1 = row.insertCell(0);
    var cell2 = row.insertCell(1);
    var cell3 = row.insertCell(2);
    var cell4 = row.insertCell(3);
    var cell5 = row.insertCell(4);
    var cell6 = row.insertCell(5);
    cell1.innerHTML = "101";
    cell2.innerHTML = "Rahul";
    cell3.innerHTML = "rahul.com";
    cell4.innerHTML = "Samsung";
    cell5.innerHTML = "";
    cell6.innerHTML = "";
}
function deleteFunction(){
    document.getElementById("tbl1").deleteRow(0);
  }

  